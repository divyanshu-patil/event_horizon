const mongoose = require("mongoose")

const velocitySchema = mongoose.Schema({
    "event_id" : {
        type : "string",
        required : true
    },
    "points" : {
        type : [{"time" : {type : "double",required : true},
        "distance" : {type : "float",required : true}}],
        required : true
    },
    "initial_velocity" : {
        type : "float",
        required : true
    },
    "model" : {
        type : "string",
        required : true
    }
})

const Velocity_Profile = mongoose.model("velocity_profiles",velocitySchema)

module.exports = Velocity_Profile