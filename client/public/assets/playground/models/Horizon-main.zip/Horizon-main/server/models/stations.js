const mongoose = require("mongoose")

const stationSchema = mongoose.Schema({
    "station_name" : {
        type : "string",
        required : true
    },
    "location" : {
        type : {"latitude" : {type : "float",required : true},
        "longitude" : {type : "float",required : true},
        "altitude" : {type : "float",required : true}},
        required : true
    },
    "shower_code" : {
        type : "string",
        required : true
    }
})

const Station = mongoose.model("stations",stationSchema)

module.exports = Station