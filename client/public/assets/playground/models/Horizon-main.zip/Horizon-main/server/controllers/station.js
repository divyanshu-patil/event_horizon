const Station = require("../models/stations")
async function handleStation(req,res){
    try{
        const event_id = req.query.event_id
        const station = await Station.findOne({event_id})
        
    }
}